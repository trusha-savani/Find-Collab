import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';



// ----------------------------------------------------------------------

export function useGetSocialAccounts() {
  const URL = endpoints.SocialAccounts.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      SocialAccountsList: data?.socialAccount || [],
      SocialAccountsListLoading: isLoading,
      SocialAccountsListError: error,
      SocialAccountsListValidating: isValidating,
      SocialAccountsListEmpty: !isLoading && !data?.products?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 