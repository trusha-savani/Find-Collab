import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetSearchCompaign() {
  const URL = endpoints.SEARCHCOMPAIGN.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      compaignList: data?.data || [],
      compaignListLoading: isLoading,
      compaignListError: error,
      compaignListValidating: isValidating,
      compaignListEmpty: !isLoading && !data?.products?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 