import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetINSTASERVICES() {
    const URL = endpoints.INSTASERVICES.list;
  
    const { data, isLoading, error, isValidating ,mutate} = useSWR(URL, fetcher);
  
    const memoizedValue = useMemo(
      () => ({
        instaservicelist: data?.instaService || [],  // Ensure it includes both `id` and `name`
        instaservicelistLoading: isLoading,
        instaservicelistError: error,
        instaservicelistValidating: isValidating,
        instaservicelistEmpty: !isLoading && !data?.instaService?.length,
        refetchInstaService: () => mutate(),
      }),
      [data, error, isLoading, isValidating,mutate]
    );
  
    return memoizedValue;
  }
 