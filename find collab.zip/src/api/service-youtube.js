import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetYoutubeService() {
  const URL = endpoints.youtube_service.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      youtubeService: data?.youtubeService || [],
      youtubeServiceLoading: isLoading,
      youtubeServiceError: error,
      youtubeServiceValidating: isValidating,
      youtubeServiceEmpty: !isLoading && !data?.youtubeService?.length,
    }),
    [data?.youtubeService, error, isLoading, isValidating]
  );

  return memoizedValue;
}

