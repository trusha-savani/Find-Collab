import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetDashboardDetails() {
  const URL = endpoints.DashboardDetails.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      DashboardList: data?.data || [],
      DashboardListLoading: isLoading,
      DashboardListError: error,
      DashboardListValidating: isValidating,
      DashboardListEmpty: !isLoading && !data?.products?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 