import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetInstgramService() {
  const URL = endpoints.instgarm_service.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      instaService: data?.instaService || [],
      instaServiceLoading: isLoading,
      instaServiceError: error,
      instaServiceValidating: isValidating,
      instaServiceEmpty: !isLoading && !data?.instaService?.length,
    }),
    [data?.instaService, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 
