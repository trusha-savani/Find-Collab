import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetINFULANCERIGSERVICE() {
    const URL = endpoints.INFULANCERIGSERVICE.list;

  
    const { data, isLoading, error, isValidating ,mutate} = useSWR(URL, fetcher);
  
    const memoizedValue = useMemo(
      () => ({
        infulancerigservicelist: data?.InfluencerinstaService || [],  // Ensure it includes both `id` and `name`
        instaservicelistLoading: isLoading,
        instaservicelistError: error,
        instaservicelistValidating: isValidating,
        instaservicelistEmpty: !isLoading && !data?.InfluencerinstaService?.length,
        refetch: () => mutate(), 
      }),
      [data, error, isLoading, isValidating,mutate]
    );
  
    return memoizedValue;
  }
 