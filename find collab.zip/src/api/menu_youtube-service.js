import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetINFULANCERYOUTUBESERVICE() {
  const URL = endpoints.youtubeMenu.list;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);

  const memoizedValue = useMemo(
    () => ({
      youtubeMenu: data?.youtubeService || [],  // Ensure it includes both `id` and `name`
      youtubeMenuLoading: isLoading,
      youtubeMenuError: error,
      youtubeMenuValidating: isValidating,
      youtubeMenuEmpty: !isLoading && !data?.youtubeService?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
