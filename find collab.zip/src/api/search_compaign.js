import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetSearchCompaign(queryparams) {
  console.log(queryparams);
  const URL = endpoints.SEARCHCOMPAIGN.list({
    page: queryparams?.page || "",
    type: queryparams?.filters?.type || "",
    gender: queryparams?.filters?.gender || "",
    locations: queryparams?.filters?.locations || "",
    minAge: queryparams?.filters?.age[0] || "",
    maxAge: queryparams?.filters?.age[1] || "",
    minimumValue: queryparams?.filters?.budget[0] || "",
    maximumValue: queryparams?.filters?.budget[1] || "",
  });

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      compaignList: data?.data || [],
      totalCampaings: data?.totalCampaings || [],
      totalPages: data?.totalPages || [],
      compaignListLoading: isLoading,
      compaignListError: error,
      compaignListValidating: isValidating,
      compaignListEmpty: !isLoading && !data?.products?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}

