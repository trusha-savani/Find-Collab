import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetFavFindInFluencer() {
  const URL = endpoints?.FavFindInFluencer.list;

  const { data, isLoading, error, isValidating ,mutate} = useSWR(URL, fetcher);
 
  const memoizedValue = useMemo(
    () => ({
        FindFavInFluencerList: data?.favouriteInfluencer || [],
        FindInFluencerListLoading: isLoading,
        FindInFluencerListError: error,
        FindInFluencerListValidating: isValidating,
        FindInFluencerListEmpty: !isLoading && !data?.products?.length,
        refetch:()=>mutate()
    }),
    [data, error, isLoading, isValidating ,mutate]
  );

  return memoizedValue;
}
 
