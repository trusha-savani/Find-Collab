import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetBrandMyCapmaign() {
  const URL = endpoints.Brand_my_camapaign.list;


  const { data, isLoading, error, isValidating, mutate } = useSWR(URL, fetcher);

  const memoizedValue = useMemo(
    () => ({
      myCampaign: data?.result || [],  // Ensure it includes both `id` and `name`
      myCampaignLoading: isLoading,
      myCampaignError: error,
      myCampaignValidating: isValidating,
      myCampaignEmpty: !isLoading && !data?.result?.length,
      refetch: () => mutate(),
    }),
    [data, error, isLoading, isValidating, mutate]
  );

  return memoizedValue;
}
