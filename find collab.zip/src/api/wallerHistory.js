import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetWalletHistory(queryParams) {
  const URL = endpoints.wallet_History.list(
    {
      type: queryParams?.filter,
      status: queryParams?.status || "All",
      page: queryParams?.page,
      limit: queryParams?.limit,

    }
  );


  const { data, isLoading, error, isValidating, mutate } = useSWR(URL, fetcher);

  const memoizedValue = useMemo(
    () => ({
      walletHistorylist: data?.formattedData || [],
      walletHistoryBrandlist: data?.paymentHistory || [],
      walletHistoryLoading: isLoading,
      walletHistoryError: error,
      walletHistoryValidating: isValidating,
      walletHistoryEmpty: !isLoading && !data?.formattedData?.length,
      WalletHistoryCount: !isLoading && data?.totalData || data?.total,
      refetch: () => mutate(),
    }),
    [data, error, isLoading, isValidating, mutate]
  );

  return memoizedValue;
}
