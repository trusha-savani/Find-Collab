import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------
export function useGetMyApplication(queryParams) {
  const URL = endpoints.MyApplication_get.list({ page: queryParams?.page, limit: queryParams?.limit, action: queryParams?.action });

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      MyapplicationList: data?.data || [],
      applicationListLoading: isLoading,
      applicationListError: error,
      applicationListValidating: isValidating,
      applicationListEmpty: !isLoading && !data?.data?.length,
      applicationListCount: !isLoading && data?.totalCount || 0,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
