import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------
export function useGetApplication(queryParams) {
  const URL = endpoints.Application_get.list(
    {
      id: queryParams?.id || "",
      action: queryParams?.action,
      page: queryParams?.page,
      limit: queryParams?.limit,

    }
  )

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      applicationList: data?.data || [],
      applicationListLoading: isLoading,
      applicationListError: error,
      applicationListValidating: isValidating,
      applicationListEmpty: !isLoading && !data?.data?.length,
      applicationListCount: !isLoading && data?.totalCount,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
