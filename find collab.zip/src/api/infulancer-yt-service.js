import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetYOUTUBESERVICE() {
    const URL = endpoints.YOUTUBESERVICE.list;

  
    const { data, isLoading, error, isValidating,mutate } = useSWR(URL, fetcher);
  
    const memoizedValue = useMemo(
      () => ({
        youtubeservicelist: data?.InfluencerYoutubeService || [],  // Ensure it includes both `id` and `name`
        instaservicelistLoading: isLoading,
        instaservicelistError: error,
        instaservicelistValidating: isValidating,
        instaservicelistEmpty: !isLoading && !data?.InfluencerYoutubeService?.length,
        refetch: () => mutate(),
      }),
      [data, error, isLoading, isValidating,mutate]
    );
  
    return memoizedValue;
  }
 