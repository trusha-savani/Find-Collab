  import useSWR from 'swr';
  import { useMemo } from 'react';

  import { fetcher, endpoints } from 'src/utils/axios';

  // ----------------------------------------------------------------------

  export function useGetBrandInfulancerSingle(id) {
    const URL = endpoints?.BrandInfulancerSingle.list(id);

    const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);
  
    const memoizedValue = useMemo(
      () => ({
          InfulancerSingleList: data?.influencer || [],
          FindInFluencerListLoading: isLoading,
          FindInFluencerListError: error,
          FindInFluencerListValidating: isValidating,
          FindInFluencerListEmpty: !isLoading && !data?.products?.length,
      }),
      [data, error, isLoading, isValidating]
    );

    return memoizedValue;
  }
  