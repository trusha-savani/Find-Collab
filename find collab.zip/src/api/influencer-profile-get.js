import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetInfluencerProfile() {
  const URL = endpoints.INFLUENCER_PROFILE.details;

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      InfluencerProfile: data?.result || [],
      InfluencerProfileLoading: isLoading,
      InfluencerProfileError: error,
      InfluencerProfileValidating: isValidating,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}

