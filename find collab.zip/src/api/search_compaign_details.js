import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------
 export function useGetSearchCompaignDetails(id) {
  const URL = endpoints.SEARCHCOMPAIGNDETAILS.list(id);

  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      compaignListDetails: data?.result || [],
      compaignSocial: data?.result?.social || [],
      compaignListLoading: isLoading,
      compaignListError: error,
      compaignListValidating: isValidating,
      compaignListEmpty: !isLoading && !data?.products?.length,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 