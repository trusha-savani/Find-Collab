import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetPastproject() {
  const URL = endpoints.Pastproject.list;

  const { data, isLoading, error, isValidating,mutate } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
        PastprojectList: data?.result || [],
      compaignListLoading: isLoading,
      compaignListError: error,
      compaignListValidating: isValidating,
      compaignListEmpty: !isLoading && !data?.products?.length,
      refetch: () => mutate(),
    }),
    [data, error, isLoading, isValidating,mutate]
  );

  return memoizedValue;
}
 