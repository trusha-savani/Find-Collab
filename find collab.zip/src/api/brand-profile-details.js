import useSWR from "swr";
import { useMemo } from "react";

import { fetcher, endpoints } from "src/utils/axios";

export function useGetBrandMyProfile() {
  const URL = endpoints.Brand_My_profile.list;


  const { data, isLoading, error, isValidating, mutate } = useSWR(URL, fetcher);

  const memoizedValue = useMemo(
    () => ({
      myProfile: data?.result || [],
      myProfileLoading: isLoading,
      myProfileError: error,
      myProfileValidating: isValidating,
      refetch: () => mutate(),
    }),
    [data?.result, error, isLoading, isValidating, mutate,]
  );

  return memoizedValue;
}