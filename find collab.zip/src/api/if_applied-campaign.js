import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------
 export function useGetAppliedCampaign(queryparams) {
   
  const URL = endpoints.APPLIDE_COMPAIGN.list({page:queryparams?.page,limit:queryparams?.limit,status:queryparams?.status});


  const { data, isLoading, error, isValidating } = useSWR(URL, fetcher);


  const memoizedValue = useMemo(
    () => ({
      appliedCompaign: data?.data || [],
      appliedCompaignLoading: isLoading,
      appliedCompaignError: error,
      appliedCompaignValidating: isValidating,
      appliedCompaignEmpty: !isLoading && !data?.data?.length,
      appliedCompaignCount: data?.totalCount || 0 ,
    }),
    [data, error, isLoading, isValidating]
  );

  return memoizedValue;
}
 