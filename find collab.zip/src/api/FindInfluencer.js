import useSWR from 'swr';
import { useMemo } from 'react';

import { fetcher, endpoints } from 'src/utils/axios';

// ----------------------------------------------------------------------

export function useGetFindInFluencer() {
  const URL = endpoints?.FindInFluencer.list;

  const { data, isLoading, error, isValidating ,mutate} = useSWR(URL, fetcher);
 
  const memoizedValue = useMemo(
    () => ({
        FindInFluencerList: data?.data || [],
        FindInFluencerListLoading: isLoading,
        FindInFluencerListError: error,
        FindInFluencerListValidating: isValidating,
        FindInFluencerListEmpty: !isLoading && !data?.products?.length,
        refetch:()=>mutate()
    }),
    [data, error, isLoading, isValidating ,mutate]
  );

  return memoizedValue;
}
 
