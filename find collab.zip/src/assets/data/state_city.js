export const indiaStatesCities = {
  "Andaman and Nicobar Islands": [
    "Port Blair"
  ],
  "Andhra Pradesh": [
    "Amaravati",
    "Visakhapatnam",
    "Vijayawada",
    "Guntur",
    "Kurnool",
    "Tirupati",
    "Nellore",
    "Rajahmundry",
    "Anantapur",
    "Chittoor"
  ],
  "Arunachal Pradesh": [
    "Itanagar",
    "Tawang",
    "Naharlagun",
    "Pasighat",
    "Ziro"
  ],
  "Assam": [
    "Guwahati",
    "Dibrugarh",
    "Jorhat",
    "Silchar",
    "Tinsukia",
    "Nagaon",
    "Barpeta",
    "Tezpur",
    "Bongaigaon",
    "Nalbari"
  ],
  "Bihar": [
    "Patna",
    "Gaya",
    "Bhagalpur",
    "Muzaffarpur",
    "Purnia",
    "Darbhanga",
    "Munger",
    "Siwan",
    "Saharsa",
    "Begusarai"
  ],
  "Chhattisgarh": [
    "Raipur",
    "Bilaspur",
    "Korba",
    "Durg",
    "Jagdalpur",
    "Raigarh",
    "Ambikapur",
    "Kanker",
    "Rajnandgaon",
    "Janjgir"
  ],
  "Goa": [
    "Panaji",
    "Margao",
    "Vasco da Gama",
    "Mapusa",
    "Ponda"
  ],
  "Gujarat": [
    "Ahmedabad",
    "Surat",
    "Vadodara",
    "Rajkot",
    "Bhavnagar",
    "Gandhinagar",
    "Anand",
    "Jamnagar",
    "Junagadh",
    "Mehsana"
  ],
  "Haryana": [
    "Chandigarh",
    "Faridabad",
    "Gurgaon",
    "Hisar",
    "Karnal",
    "Sonipat",
    "Ambala",
    "Panipat",
    "Yamunanagar",
    "Rohtak"
  ],
  "Himachal Pradesh": [
    "Shimla",
    "Kullu",
    "Manali",
    "Dharamshala",
    "Solan",
    "Mandi",
    "Kangra",
    "Hamirpur",
    "Bilaspur",
    "Chamba"
  ],
  "Jharkhand": [
    "Ranchi",
    "Jamshedpur",
    "Dhanbad",
    "Deoghar",
    "Hazaribagh",
    "Giridih",
    "Jamtara",
    "Dumka",
    "Chaibasa",
    "Ramgarh"
  ],
  "Karnataka": [
    "Bangalore",
    "Mysore",
    "Hubli",
    "Dharwad",
    "Mangalore",
    "Belagavi",
    "Tumkur",
    "Shimoga",
    "Bijapur",
    "Bagalkot"
  ],
  "Kerala": [
    "Thiruvananthapuram",
    "Kochi",
    "Kozhikode",
    "Kottayam",
    "Thrissur",
    "Palakkad",
    "Malappuram",
    "Alappuzha",
    "Idukki",
    "Ernakulam"
  ],
  "Madhya Pradesh": [
    "Bhopal",
    "Indore",
    "Gwalior",
    "Jabalpur",
    "Ujjain",
    "Sagar",
    "Rewa",
    "Satna",
    "Khandwa",
    "Chhindwara"
  ],
  "Maharashtra": [
    "Mumbai",
    "Pune",
    "Nagpur",
    "Nashik",
    "Aurangabad",
    "Thane",
    "Kalyan",
    "Navi Mumbai",
    "Solapur",
    "Amravati"
  ],
  "Manipur": [
    "Imphal",
    "Churachandpur",
    "Thoubal",
    "Kangpokpi",
    "Senapati"
  ],
  "Meghalaya": [
    "Shillong",
    "Tura",
    "Jowai",
    "Nongpoh",
    "Williamnagar"
  ],
  "Mizoram": [
    "Aizawl",
    "Lunglei",
    "Champhai",
    "Serchhip",
    "Kolasib"
  ],
  "Nagaland": [
    "Kohima",
    "Dimapur",
    "Mokokchung",
    "Wokha",
    "Tuensang"
  ],
  "Odisha": [
    "Bhubaneswar",
    "Cuttack",
    "Rourkela",
    "Berhampur",
    "Sambalpur",
    "Bargarh",
    "Balasore",
    "Kendrapara",
    "Kalahandi",
    "Koraput"
  ],
  "Punjab": [
    "Chandigarh",
    "Amritsar",
    "Ludhiana",
    "Jalandhar",
    "Patiala",
    "Bathinda",
    "Mohali",
    "Moga",
    "Hoshiarpur",
    "Fatehgarh Sahib"
  ],
  "Rajasthan": [
    "Jaipur",
    "Udaipur",
    "Jodhpur",
    "Ajmer",
    "Kota",
    "Bikaner",
    "Alwar",
    "Jaisalmer",
    "Sikar",
    "Chittorgarh"
  ],
  "Sikkim": [
    "Gangtok",
    "Namchi",
    "Mangan",
    "Rangpo",
    "Jorethang"
  ],
  "Tamil Nadu": [
    "Chennai",
    "Coimbatore",
    "Madurai",
    "Tiruchirappalli",
    "Salem",
    "Tirunelveli",
    "Erode",
    "Vellore",
    "Tiruppur",
    "Thanjavur"
  ],
  "Telangana": [
    "Hyderabad",
    "Warangal",
    "Khammam",
    "Karimnagar",
    "Nizamabad",
    "Mahbubnagar",
    "Sangareddy",
    "Ramagundam",
    "Nalgonda",
    "Adilabad"
  ],
  "Tripura": [
    "Agartala",
    "Dharmanagar",
    "Udaipur",
    "Kailashahar",
    "Ambassa"
  ],
  "Uttar Pradesh": [
    "Lucknow",
    "Kanpur",
    "Agra",
    "Varanasi",
    "Allahabad",
    "Gorakhpur",
    "Bareilly",
    "Meerut",
    "Jhansi",
    "Aligarh"
  ],
  "Uttarakhand": [
    "Dehradun",
    "Nainital",
    "Haridwar",
    "Rishikesh",
    "Roorkee",
    "Haldwani",
    "Haridwar",
    "Pantnagar"
  ],
  "West Bengal": [
    "Kolkata",
    "Siliguri",
    "Howrah",
    "Durgapur",
    "Asansol",
    "Burdwan",
    "Malda",
    "Kolkata",
    "Jalpaiguri",
    "Medinipur"
  ]
};


