import PropTypes from 'prop-types';
import { useMemo, useEffect, useReducer, useCallback } from 'react';

import axios, { endpoints } from 'src/utils/axios';

import { AuthContext } from './auth-context';
import { setSession, isValidToken } from './utils';

// ----------------------------------------------------------------------


// Function to encode data to Base64
function encodeData(data, secretKey = "deep123") {
  // If data is an object, convert it to a JSON string
  if (typeof data === "object") {
    data = JSON.stringify(data);
  }

  // Add a timestamp to the data
  const timestamp = new Date().getTime(); // Current timestamp in milliseconds
  const dataWithTimestamp = `${data}|${timestamp}|${secretKey}`;

  // Encode the data with Base64
  return btoa(dataWithTimestamp);
}





const initialState = {
  user: null,
  loading: true,
};

const reducer = (state, action) => {
  if (action.type === 'INITIAL') {
    return {
      loading: false,
      user: action.payload.user,
    };
  }
  if (action.type === 'LOGIN') {
    return {
      ...state,
      user: action.payload.user,
    };
  }
  if (action.type === 'REGISTER') {
    return {
      ...state,
      user: action.payload.user,
    };
  }
  if (action.type === 'LOGOUT') {
    return {
      ...state,
      user: null,
    };
  }
  return state;
};

// ----------------------------------------------------------------------

const STORAGE_KEY = 'accessToken';

export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const initialize = useCallback(async () => {
    try {
      const accessToken = sessionStorage.getItem(STORAGE_KEY);

      if (accessToken && isValidToken(accessToken)) {
        setSession(accessToken);

        // Fetch user data if needed, but for simplicity, we'll just use the token
        dispatch({
          type: 'INITIAL',
          payload: {
            user: {
              accessToken,
            },
          },
        });
      } else {
        dispatch({
          type: 'INITIAL',
          payload: {
            user: null,
          },
        });
      }
    } catch (error) {
      console.error(error);
      dispatch({
        type: 'INITIAL',
        payload: {
          user: null,
        },
      });
    }
  }, []);

  useEffect(() => {
    initialize();
  }, [initialize]);

  // LOGIN
  const login = useCallback(async (contact, password) => {
    const data = {
      contact,
      password,
    };

    const response = await axios.post(endpoints.auth.login, data);
    console.log("response====>logn", response);

    const { accessToken, type } = response.data;
    console.log(type);
    const encodedData = encodeData(type);
    console.log("Encoded Data:", encodedData);


    sessionStorage.setItem('type', encodedData);
    setSession(accessToken);

    dispatch({
      type: 'LOGIN',
      payload: {
        user: {
          accessToken,
        },
      },
    });
  }, []);

  // REGISTER
  const register = useCallback(async (phoneNumber, password, firstName, lastName) => {
    const data = {
      phoneNumber,
      password,
      firstName,
      lastName,
    };

    const response = await axios.post(endpoints.auth.register, data);

    const { token } = response.data;

    sessionStorage.setItem(STORAGE_KEY, token);

    dispatch({
      type: 'REGISTER',
      payload: {
        user: {
          accessToken: token,
        },
      },
    });
  }, []);

  // LOGOUT
  const logout = useCallback(async () => {
    setSession(null);
    dispatch({
      type: 'LOGOUT',
    });
  }, []);

  // ----------------------------------------------------------------------

  const checkAuthenticated = state.user ? 'authenticated' : 'unauthenticated';

  const status = state.loading ? 'loading' : checkAuthenticated;

  const memoizedValue = useMemo(
    () => ({
      user: state.user,
      method: 'jwt',
      loading: status === 'loading',
      authenticated: status === 'authenticated',
      unauthenticated: status === 'unauthenticated',
      //
      login,
      register,
      logout,
    }),
    [login, logout, register, state.user, status]
  );

  return <AuthContext.Provider value={memoizedValue}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node,
};