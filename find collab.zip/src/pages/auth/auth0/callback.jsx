import { SplashScreen } from 'src/components/loading-screen';

// ----------------------------------------------------------------------

export default function CallbackPage() {
  return <SplashScreen />;
}
