import { Helmet } from 'react-helmet-async';

import { JwtRegisterInfluencerView } from 'src/sections/auth/jwt';



// ----------------------------------------------------------------------

export default function RegisterInfluencerPage() {
  return (
    <>
      <Helmet>
        <title> Jwt: Register</title>
      </Helmet>

      <JwtRegisterInfluencerView />
    </>
  );
}
