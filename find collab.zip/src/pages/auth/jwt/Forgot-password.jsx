import { Helmet } from 'react-helmet-async';

import { JwtForgotPasswordView } from 'src/sections/auth/jwt';

// ----------------------------------------------------------------------

export default function Forgotpassword() {
  return (
    <>
      <Helmet>
        <title> Jwt: forgotPassword</title>
      </Helmet>

      <JwtForgotPasswordView />
    </>
  );
}

