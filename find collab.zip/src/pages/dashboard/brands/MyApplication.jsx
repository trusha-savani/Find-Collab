import { Helmet } from 'react-helmet-async';

import MyApplicationListView from 'src/sections/overview/myapplication/view/MyApplication-list-view';

// import { MyApplicationListView } from 'src/sections/overview/Application/view';
 
  

// ----------------------------------------------------------------------

export default function ApplicationListPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <MyApplicationListView />
    </>
  );
}
