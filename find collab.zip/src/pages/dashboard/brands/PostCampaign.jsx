import { Helmet } from 'react-helmet-async';

 import { PostCampaignsView } from 'src/sections/overview/PostCampaign/view';
 

// ----------------------------------------------------------------------

export default function PostCampaignPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Post Campaignpage</title>
      </Helmet>
 
      <PostCampaignsView />
    </>
  );
}
