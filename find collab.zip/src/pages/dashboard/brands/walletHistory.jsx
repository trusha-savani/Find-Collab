import { Helmet } from 'react-helmet-async';

import {  WalletHistoryView } from 'src/sections/overview/walletHistory/view';



// ----------------------------------------------------------------------

export default function WalletHistoryPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>

      <WalletHistoryView />
    </>
  );
}
