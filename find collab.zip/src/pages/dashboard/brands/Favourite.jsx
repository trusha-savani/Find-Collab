import { Helmet } from 'react-helmet-async';

import { FindInfluencerView } from 'src/sections/overview/Favourite/view';

 
  

// ----------------------------------------------------------------------

export default function Favourite() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <FindInfluencerView />
    </>
  );
}
