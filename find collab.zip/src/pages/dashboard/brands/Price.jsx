import { Helmet } from 'react-helmet-async';

import { PriceListView } from 'src/sections/overview/pricing/view';

 
  

// ----------------------------------------------------------------------

export default function PriceListPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <PriceListView />
    </>
  );
}
