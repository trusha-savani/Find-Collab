import { Helmet } from 'react-helmet-async';

import { MyCampaignsView } from 'src/sections/overview/my-campaigns/view';
 

// ----------------------------------------------------------------------

export default function MyCampaignPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Post Campaignpage</title>
      </Helmet>
 
      <MyCampaignsView />
    </>
  );
}
