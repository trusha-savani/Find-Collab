import { Helmet } from 'react-helmet-async';

import { MediaKitView } from 'src/sections/overview/Media-kit/view';




// ----------------------------------------------------------------------

export default function MediaKitPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>

      <MediaKitView />
    </>
  );
}
