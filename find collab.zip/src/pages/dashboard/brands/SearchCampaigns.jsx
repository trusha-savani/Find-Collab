import React from 'react'
import { Helmet } from 'react-helmet-async'

import { SearchCampaignsview } from 'src/sections/overview/SearchCampaigns/view'
 
export default function SearchCampaigns() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <SearchCampaignsview />
    </>
  );
}