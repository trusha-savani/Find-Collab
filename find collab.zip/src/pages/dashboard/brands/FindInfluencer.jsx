import { Helmet } from 'react-helmet-async';

import { FindInfluencerView } from 'src/sections/overview/FindInfluencer/view';

  

// ----------------------------------------------------------------------

export default function FindInfluencer() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <FindInfluencerView />
    </>
  );
}
