import { Helmet } from 'react-helmet-async';

import { ApplicationListView } from 'src/sections/overview/Application/view';
 
  

// ----------------------------------------------------------------------

export default function ApplicationListPage() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <ApplicationListView />
    </>
  );
}
