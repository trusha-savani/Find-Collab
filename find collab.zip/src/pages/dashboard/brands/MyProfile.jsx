import { Helmet } from 'react-helmet-async';

import { MyProfileView } from 'src/sections/overview/Admin/view';


// ----------------------------------------------------------------------

export default function MyProfilepage() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Post Campaignpage</title>
      </Helmet>
 
      <MyProfileView />
    </>
  );
}
