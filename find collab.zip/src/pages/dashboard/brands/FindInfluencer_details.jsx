import { Helmet } from 'react-helmet-async';

import {  InfluencerMediaKitView } from 'src/sections/overview/FindInfluencer/view';

  

// ----------------------------------------------------------------------

export default function FindInfluencerDetails() {
  return (
    <>
      <Helmet>
        <title> Dashboard : Find Influencer</title>
      </Helmet>
 
      <InfluencerMediaKitView />
    </>
  );
}
