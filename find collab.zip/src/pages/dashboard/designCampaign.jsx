import { Helmet } from 'react-helmet-async';

import { DesignCampaigns } from 'src/sections/overview/Design-Campaigns/view';
 

// ----------------------------------------------------------------------

export default function DesignCampaignpage() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Design Campaignpage</title>
      </Helmet>

      <DesignCampaigns />
    </>
  );
}
