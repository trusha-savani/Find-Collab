import { Helmet } from 'react-helmet-async';

 import { SucessfullyView } from 'src/sections/Sucessfully/view';

// ----------------------------------------------------------------------

export default function SucessfullyPage() {
  return (
    <>
      <Helmet>
        <title> Minimal: The starting point for your next project</title>
      </Helmet>

      <SucessfullyView />
    </>
  );
}
