export * from './config-lang';

export * from './use-locales';

export { default as LocalizationProvider } from './localization-provider';
