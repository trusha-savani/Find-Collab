 

export function DecodeData(encodedData, secretKey = "deep123") {
  try {
    // Decode the Base64 string
    const decodedString = atob(encodedData);

    // Split the decoded string into parts
    const [data, timestamp, key] = decodedString.split('|');

    // Check if the secretKey matches
    if (key !== secretKey) {
      throw new Error('Invalid secret key.');
    }

    // Validate the timestamp (Optional: You can add expiration logic here)
    const currentTime = new Date().getTime();
    if (currentTime - parseInt(timestamp, 10) > 24 * 60 * 60 * 1000) {
      // Example: Consider the data expired if it's older than 24 hours
      throw new Error('Data has expired.');
    }

    // Try parsing the data back to an object
    try {
      return JSON.parse(data);
    } catch (e) {
      // If parsing fails, return the raw string
      return data;
    }
  } catch (error) {
    console.error('Failed to decode data:', error.message);
    return null; // Return null in case of failure
  }
}
